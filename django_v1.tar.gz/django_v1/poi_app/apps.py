from django.apps import AppConfig


class PoiAppConfig(AppConfig):
    name = 'poi_app'
